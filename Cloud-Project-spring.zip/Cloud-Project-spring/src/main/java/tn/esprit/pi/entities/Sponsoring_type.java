package tn.esprit.pi.entities;

public enum Sponsoring_type {
    materiel,financier
}
