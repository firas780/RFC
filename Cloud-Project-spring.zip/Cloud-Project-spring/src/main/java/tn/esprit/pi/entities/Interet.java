package tn.esprit.pi.entities;

public enum Interet {
    sport,music,tech,photographie,design,dessin,robots
}
