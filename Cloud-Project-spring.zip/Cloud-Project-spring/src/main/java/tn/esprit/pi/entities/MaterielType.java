package tn.esprit.pi.entities;

public enum MaterielType {
    Laptop,Data_show,no_material,Tables_chairs,
}
