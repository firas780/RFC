package tn.esprit.pi.entities;

public enum Event_type {
    prive,publique,payant,gratuit
}
