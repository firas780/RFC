package tn.esprit.pi.entities;

public enum Feedback_type {
    positif,negatif,neutre
}
