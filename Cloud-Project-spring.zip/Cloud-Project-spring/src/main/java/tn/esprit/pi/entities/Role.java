package tn.esprit.pi.entities;

public enum Role {
    super_admin,admin_club,user
}
